Delivery Judge AI - GitHub Pages公開用

iPhoneだけで公開する最短手順:
1. GitHubで無料アカウントにログイン
2. New repository を作成
3. このZIPを展開し、index.html / manifest.webmanifest / .nojekyll をアップロード
4. Repository Settings > Pages
5. Build and deployment: Deploy from a branch
6. Branch: main / root を選んでSave
7. 数分後に表示される https://ユーザー名.github.io/リポジトリ名/ をSafariで開く
8. Safari共有ボタン > ホーム画面に追加

ローカルHTMLではなくHTTPS URLで開くことで、外部OCRライブラリが正常に読み込まれやすくなります。
